clc; clear all; close all;
disp('Hello world!')
function [sys,x0,str,ts] = sldemo_tanksfun(t,x,u,flag,varargin)

persistent simulationStartTime;
if isempty(simulationStartTime)
    simulationStartTime = now;
end

switch flag
    case 0
        [sys,x0,str,ts] = mdlInitializeSizes();
    case 2
        sys = mdlUpdate(t,x,u);
    case 3
        sys = mdlOutputs(t,x,u);
    case 9
        sys = mdlTerminate(t,x,u);
    otherwise
        sys = [];
end

    function [sys,x0,str,ts] = mdlInitializeSizes()
        sizes = simsizes;
        sizes.NumContStates  = 0;
        sizes.NumDiscStates  = 0;
        sizes.NumOutputs     = 0;
        sizes.NumInputs      = 4;  % inflow, tank_height, outflow, setpoint
        sizes.DirFeedthrough = 0;
        sizes.NumSampleTimes = 1;
        sys = simsizes(sizes);
        str = [];
        x0  = [];
        ts  = [-1 0];
        initializeTankGUI();
    end

    function sys = mdlUpdate(t,x,u)
        global tankData;
        if ~exist('tankData', 'var') || isempty(tankData)
            initializeTankGUI();
        end
        if tankData.isInitialized
            tankData.current.time = t;
            tankData.current.level = u(2);      % ارتفاع تانک از ورودی دوم
            tankData.current.inflow = u(1);     % نرخ ورودی از ورودی اول
            tankData.current.outflow = u(3);    % نرخ خروجی از ورودی سوم
            tankData.current.setpoint = u(4);   % نقطه تنظیم از ورودی چهارم
            
            idx = mod(tankData.history.index, tankData.history.bufferSize) + 1;
            tankData.history.time(idx) = t;
            tankData.history.level(idx) = u(2);      % ارتفاع تانک
            tankData.history.inflow(idx) = u(1);     % نرخ ورودی (مهم برای انیمیشن)
            tankData.history.outflow(idx) = u(3);    % نرخ خروجی
            tankData.history.setpoint(idx) = u(4);   % نقطه تنظیم
            tankData.history.index = idx;
            
            if tankData.history.index > 1
                prev_idx = mod(tankData.history.index-2, tankData.history.bufferSize) + 1;
                dt = t - tankData.history.time(prev_idx);
                if dt > 0
                    dlevel = u(2) - tankData.history.level(prev_idx);
                    tankData.history.dlevel_dt(idx) = dlevel/dt;
                    
                    % نرخ تغییر inflow برای انیمیشن
                    dinflow = u(1) - tankData.history.inflow(prev_idx);
                    tankData.history.dinflow_dt(idx) = dinflow/dt;
                else
                    tankData.history.dlevel_dt(idx) = 0;
                    tankData.history.dinflow_dt(idx) = 0;
                end
            else
                tankData.history.dlevel_dt(idx) = 0;
                tankData.history.dinflow_dt(idx) = 0;
            end
            
            updateRealTimeDisplay();
            
            if u(1) > tankData.statistics.maxInflow
                tankData.statistics.maxInflow = u(1);
                tankData.statistics.maxInflowTime = t;
            end
            if u(1) < tankData.statistics.minInflow || tankData.history.index == 1
                tankData.statistics.minInflow = u(1);
                tankData.statistics.minInflowTime = t;
            end
            
            if u(2) > tankData.statistics.maxHeight
                tankData.statistics.maxHeight = u(2);
                tankData.statistics.maxHeightTime = t;
            end
            if u(2) < tankData.statistics.minHeight || tankData.history.index == 1
                tankData.statistics.minHeight = u(2);
                tankData.statistics.minHeightTime = t;
            end
        end
        sys = [];
    end

    function sys = mdlOutputs(t,x,u)
        sys = [];
    end

    function sys = mdlTerminate(t,x,u)
        global tankData;
        fprintf('\n=== Simulation Complete ===\n');
        fprintf('Final Time: %.1f seconds\n', t);
        fprintf('Final Tank Height: %.3f meters\n', tankData.current.level);
        fprintf('Final Inflow Rate: %.3f m³/s\n', tankData.current.inflow);
        fprintf('Maximum Inflow: %.3f m³/s at t=%.1f s\n', tankData.statistics.maxInflow, tankData.statistics.maxInflowTime);
        fprintf('Minimum Inflow: %.3f m³/s at t=%.1f s\n', tankData.statistics.minInflow, tankData.statistics.minInflowTime);
        fprintf('Maximum Height: %.3f meters at t=%.1f s\n', tankData.statistics.maxHeight, tankData.statistics.maxHeightTime);
        fprintf('Minimum Height: %.3f meters at t=%.1f s\n', tankData.statistics.minHeight, tankData.statistics.minHeightTime);
        fprintf('Data Points Collected: %d\n', tankData.history.index);
        
        if tankData.isInitialized
            updateFinalStateDisplay();
            showInflowSummary();
            generateFinalPlots();
        end
        sys = [];
    end

end

function initializeTankGUI()
    global tankData tankFig;
    fprintf('Initializing Tank GUI with Inflow Animation...\n');
    if exist('tankFig', 'var') && ~isempty(tankFig) && isgraphics(tankFig)
        close(tankFig);
    end
    tankData = struct();
    tankData.isInitialized = false;
    tankData.updateCounter = 0;
    tankData.config.tankMaxHeight = 10;
    tankData.config.tankDiameter = 5;
    tankData.config.maxInflow = 2.0;  % حداکثر نرخ ورودی برای نرمال سازی
    tankData.config.displayScale = 1.0;
    fprintf('Tank Configuration:\n');
    fprintf('  Max Height: %.1f meters\n', tankData.config.tankMaxHeight);
    fprintf('  Diameter: %.1f meters\n', tankData.config.tankDiameter);
    fprintf('  Max Inflow: %.1f m³/s\n', tankData.config.maxInflow);
    tankFig = figure('Name', 'WATER TANK - INFLOW ANIMATION', 'NumberTitle', 'off', 'Position', [50, 50, 1400, 800], 'Color', [0.95 0.95 0.98], 'MenuBar', 'none', 'ToolBar', 'none', 'CloseRequestFcn', @closeTankGUI, 'ResizeFcn', @resizeGUI);
    tankData.figure = tankFig;
    createMainLayout();
    initializeTankVisualization();
    initializeDataDisplays();
    initializeControlPanel();
    tankData.history.bufferSize = 10000;
    tankData.history.time = zeros(1, tankData.history.bufferSize);
    tankData.history.level = zeros(1, tankData.history.bufferSize);
    tankData.history.inflow = zeros(1, tankData.history.bufferSize);
    tankData.history.outflow = zeros(1, tankData.history.bufferSize);
    tankData.history.setpoint = zeros(1, tankData.history.bufferSize);
    tankData.history.dlevel_dt = zeros(1, tankData.history.bufferSize);
    tankData.history.dinflow_dt = zeros(1, tankData.history.bufferSize);
    tankData.history.index = 0;
    tankData.statistics.maxHeight = -inf;
    tankData.statistics.minHeight = inf;
    tankData.statistics.maxInflow = -inf;
    tankData.statistics.minInflow = inf;
    tankData.statistics.maxHeightTime = 0;
    tankData.statistics.minHeightTime = 0;
    tankData.statistics.maxInflowTime = 0;
    tankData.statistics.minInflowTime = 0;
    tankData.current.time = 0;
    tankData.current.level = 0;
    tankData.current.inflow = 0;
    tankData.current.outflow = 0;
    tankData.current.setpoint = 0;
    tankData.isInitialized = true;
    updateRealTimeDisplay();
    fprintf('Inflow Animation GUI Initialized Successfully!\n');
end

function createMainLayout()
    global tankData;
    tankData.panels.statusBar = uipanel('Parent', tankData.figure, 'BackgroundColor', [0.1 0.3 0.6], 'BorderType', 'none', 'Position', [0, 0.97, 1, 0.03]);
    tankData.graphics.statusText = uicontrol('Parent', tankData.panels.statusBar, 'Style', 'text', 'String', 'INFLOW ANIMATION: Initializing...', 'FontSize', 10, 'FontWeight', 'bold', 'ForegroundColor', [1 1 1], 'BackgroundColor', [0.1 0.3 0.6], 'HorizontalAlignment', 'left', 'Position', [10, 2, 600, 20]);
    tankData.graphics.inflowIndicator = uicontrol('Parent', tankData.panels.statusBar, 'Style', 'text', 'String', 'Inflow: 0.000 m³/s | Height: 0.000 m', 'FontSize', 10, 'FontWeight', 'bold', 'ForegroundColor', [1 1 0.8], 'BackgroundColor', [0.1 0.3 0.6], 'HorizontalAlignment', 'right', 'Position', [700, 2, 300, 20]);
    tankData.panels.mainContainer = uipanel('Parent', tankData.figure, 'BackgroundColor', [0.95 0.95 0.98], 'BorderType', 'none', 'Position', [0, 0, 1, 0.97]);
    tankData.panels.visualization = uipanel('Parent', tankData.panels.mainContainer, 'Title', 'INFLOW ANIMATION & TANK HEIGHT', 'FontSize', 14, 'FontWeight', 'bold', 'ForegroundColor', [0 0.4 0.8], 'BackgroundColor', [1 1 1], 'BorderType', 'etchedin', 'Position', [0.02, 0.02, 0.73, 0.96]);
    tankData.panels.data = uipanel('Parent', tankData.panels.mainContainer, 'Title', 'REAL-TIME INFLOW DATA & CONTROLS', 'FontSize', 14, 'FontWeight', 'bold', 'ForegroundColor', [0 0.4 0.8], 'BackgroundColor', [1 1 1], 'BorderType', 'etchedin', 'Position', [0.76, 0.02, 0.22, 0.96]);
end

function initializeTankVisualization()
    global tankData;
    tankData.axes.tank = axes('Parent', tankData.panels.visualization, 'Units', 'normalized', 'Position', [0.1, 0.1, 0.8, 0.8], 'Box', 'on', 'Color', [0.92 0.96 1], 'XColor', [0.3 0.3 0.3], 'YColor', [0.3 0.3 0.3], 'GridColor', [0.8 0.8 0.8], 'GridAlpha', 0.3, 'NextPlot', 'add');
    title(tankData.axes.tank, sprintf('INFLOW ANIMATION (Max Height: %.1f m)', tankData.config.tankMaxHeight), 'FontSize', 16, 'FontWeight', 'bold', 'Color', [0 0.3 0.6]);
    xlabel(tankData.axes.tank, 'Width (m)', 'FontSize', 12);
    ylabel(tankData.axes.tank, 'HEIGHT (m) | INFLOW INTENSITY', 'FontSize', 12, 'FontWeight', 'bold');
    grid(tankData.axes.tank, 'on');
    tankData.graphics.displayWidth = tankData.config.tankDiameter;
    tankData.graphics.displayHeight = tankData.config.tankMaxHeight * 1.1;
    tankX = [-tankData.graphics.displayWidth/2, tankData.graphics.displayWidth/2, tankData.graphics.displayWidth/2, -tankData.graphics.displayWidth/2];
    tankY = [0, 0, tankData.graphics.displayHeight, tankData.graphics.displayHeight];
    tankData.graphics.tankOutline = plot(tankData.axes.tank, [tankX, tankX(1)], [tankY, tankY(1)], 'b-', 'LineWidth', 4, 'Color', [0 0.3 0.6]);
    maxHeightY = tankData.config.tankMaxHeight;
    plot(tankData.axes.tank, [-tankData.graphics.displayWidth/2, tankData.graphics.displayWidth/2], [maxHeightY, maxHeightY], 'r--', 'LineWidth', 2, 'Color', [1 0 0]);
    text(tankData.axes.tank, tankData.graphics.displayWidth/2 + 0.5, maxHeightY, sprintf('MAX: %.1f m', maxHeightY), 'FontSize', 11, 'FontWeight', 'bold', 'Color', [1 0 0], 'BackgroundColor', [1 1 1]);
    waterX = [-tankData.graphics.displayWidth/2, tankData.graphics.displayWidth/2, tankData.graphics.displayWidth/2, -tankData.graphics.displayWidth/2];
    waterY = [0, 0, 0, 0];
    tankData.graphics.water = patch(tankData.axes.tank, waterX, waterY, [0.2 0.5 0.9], 'FaceAlpha', 0.8, 'EdgeColor', 'none');
    for h = 0:1:tankData.config.tankMaxHeight
        plot(tankData.axes.tank, [-tankData.graphics.displayWidth/2 - 0.2, -tankData.graphics.displayWidth/2], [h, h], 'k-', 'LineWidth', 1.5);
        if mod(h, 2) == 0
            text(tankData.axes.tank, -tankData.graphics.displayWidth/2 - 0.5, h, sprintf('%d m', h), 'FontSize', 10, 'FontWeight', 'bold', 'HorizontalAlignment', 'right', 'Color', [0 0 0], 'BackgroundColor', [1 1 1 0.7]);
        end
    end
    valveSize = 0.5;
    valveHeight = tankData.graphics.displayHeight * 0.7;
    tankData.graphics.inValve = rectangle('Parent', tankData.axes.tank, 'Position', [-tankData.graphics.displayWidth/2 - valveSize, valveHeight, valveSize, valveSize*2], 'FaceColor', [1 0.3 0.3], 'EdgeColor', 'k', 'LineWidth', 2, 'Curvature', [0.4, 0.4]);
    inletPipeX = [-tankData.graphics.displayWidth/2 - valveSize*2, -tankData.graphics.displayWidth/2 - valveSize];
    inletPipeY = [valveHeight + valveSize, valveHeight + valveSize];
    tankData.graphics.inletPipe = plot(tankData.axes.tank, inletPipeX, inletPipeY, 'k-', 'LineWidth', 8);
    outletHeight = tankData.graphics.displayHeight * 0.3;
    tankData.graphics.outValve = rectangle('Parent', tankData.axes.tank, 'Position', [tankData.graphics.displayWidth/2, outletHeight, valveSize, valveSize*2], 'FaceColor', [1 0.3 0.3], 'EdgeColor', 'k', 'LineWidth', 2, 'Curvature', [0.4, 0.4]);
    outletPipeX = [tankData.graphics.displayWidth/2 + valveSize, tankData.graphics.displayWidth/2 + valveSize*2];
    outletPipeY = [outletHeight + valveSize, outletHeight + valveSize];
    tankData.graphics.outletPipe = plot(tankData.axes.tank, outletPipeX, outletPipeY, 'k-', 'LineWidth', 8);
    xlim(tankData.axes.tank, [-tankData.graphics.displayWidth/2 - 2, tankData.graphics.displayWidth/2 + 2]);
    ylim(tankData.axes.tank, [-0.5, tankData.graphics.displayHeight + 0.5]);
    percentages = [0, 25, 50, 75, 100];
    for p = percentages
        heightVal = (p/100) * tankData.config.tankMaxHeight;
        text(tankData.axes.tank, tankData.graphics.displayWidth/2 + 0.5, heightVal, sprintf('%d%%', p), 'FontSize', 10, 'FontWeight', 'bold', 'HorizontalAlignment', 'left', 'Color', [0.5 0.5 0.5]);
    end
    tankData.graphics.inflowText = text(tankData.axes.tank, tankData.graphics.displayWidth/2 + 0.8, 0, '', 'FontSize', 12, 'FontWeight', 'bold', 'Color', [0 0.6 0], 'BackgroundColor', [1 1 1 0.9], 'EdgeColor', [0 0.6 0], 'Margin', 2);
    hold(tankData.axes.tank, 'off');
end

function initializeDataDisplays()
    global tankData;
    panel = tankData.panels.data;
    inflowPanel = uipanel('Parent', panel, 'Title', 'INFLOW INFORMATION', 'FontSize', 12, 'FontWeight', 'bold', 'ForegroundColor', [0 0.5 0], 'BackgroundColor', [0.95 0.97 1], 'BorderType', 'etchedin', 'Position', [0.05, 0.75, 0.9, 0.22]);
    uicontrol('Parent', inflowPanel, 'Style', 'text', 'String', 'CURRENT INFLOW', 'FontSize', 11, 'FontWeight', 'bold', 'ForegroundColor', [0 0.4 0.8], 'BackgroundColor', [0.95 0.97 1], 'HorizontalAlignment', 'center', 'Position', [10, 50, 180, 25]);
    tankData.graphics.inflowDisplay = uicontrol('Parent', inflowPanel, 'Style', 'text', 'String', '0.000', 'FontSize', 24, 'FontWeight', 'bold', 'ForegroundColor', [0 0.6 0], 'BackgroundColor', [1 1 1], 'HorizontalAlignment', 'center', 'Position', [10, 15, 180, 40]);
    uicontrol('Parent', inflowPanel, 'Style', 'text', 'String', 'm³/s', 'FontSize', 10, 'ForegroundColor', [0.4 0.4 0.4], 'BackgroundColor', [0.95 0.97 1], 'HorizontalAlignment', 'center', 'Position', [10, 5, 180, 15]);
    uicontrol('Parent', inflowPanel, 'Style', 'text', 'String', 'INFLOW STATUS', 'FontSize', 11, 'FontWeight', 'bold', 'ForegroundColor', [0 0.4 0.8], 'BackgroundColor', [0.95 0.97 1], 'HorizontalAlignment', 'center', 'Position', [200, 50, 180, 25]);
    tankData.graphics.inflowStatus = uicontrol('Parent', inflowPanel, 'Style', 'text', 'String', 'IDLE', 'FontSize', 24, 'FontWeight', 'bold', 'ForegroundColor', [0.5 0.5 0.5], 'BackgroundColor', [1 1 1], 'HorizontalAlignment', 'center', 'Position', [200, 15, 180, 40]);
    dataPanel = uipanel('Parent', panel, 'Title', 'SYSTEM DATA', 'FontSize', 12, 'FontWeight', 'bold', 'ForegroundColor', [0 0.4 0.8], 'BackgroundColor', [0.95 0.97 1], 'BorderType', 'etchedin', 'Position', [0.05, 0.4, 0.9, 0.18]);
    params = {
        {'TIME', 's', 'timeDisplay', [0.05, 0.75, 0.4, 0.2]};
        {'INFLOW', 'm³/s', 'inflowDisplay2', [0.55, 0.75, 0.4, 0.2]};
        {'OUTFLOW', 'm³/s', 'outflowDisplay', [0.05, 0.45, 0.4, 0.2]};
        {'HEIGHT', 'm', 'heightDisplay', [0.55, 0.45, 0.4, 0.2]};
        {'INFLOW RATE', 'm³/s²', 'inflowRateDisplay', [0.05, 0.15, 0.4, 0.2]};
        {'SETPOINT', 'm', 'setpointDisplay', [0.55, 0.15, 0.4, 0.2]};
    };
    for i = 1:length(params)
        titleText = params{i}{1};
        unit = params{i}{2};
        fieldName = params{i}{3};
        pos = params{i}{4};
        uicontrol('Parent', dataPanel, 'Style', 'text', 'String', titleText, 'FontSize', 9, 'FontWeight', 'bold', 'ForegroundColor', [0.2 0.2 0.6], 'BackgroundColor', [0.95 0.97 1], 'HorizontalAlignment', 'center', 'Position', [pos(1)*380, pos(2)*100 + 20, pos(3)*380, 20]);
        valueCtrl = uicontrol('Parent', dataPanel, 'Style', 'text', 'String', '0.00', 'FontSize', 11, 'FontWeight', 'bold', 'ForegroundColor', [0.1 0.1 0.1], 'BackgroundColor', [1 1 1], 'HorizontalAlignment', 'center', 'Position', [pos(1)*380, pos(2)*100, pos(3)*380, 25]);
        uicontrol('Parent', dataPanel, 'Style', 'text', 'String', unit, 'FontSize', 8, 'ForegroundColor', [0.4 0.4 0.4], 'BackgroundColor', [0.95 0.97 1], 'HorizontalAlignment', 'center', 'Position', [pos(1)*380, pos(2)*100 - 10, pos(3)*380, 15]);
        tankData.graphics.(fieldName) = valueCtrl;
    end
    historyPanel = uipanel('Parent', panel, 'Title', 'INFLOW HISTORY', 'FontSize', 12, 'FontWeight', 'bold', 'ForegroundColor', [0 0.4 0.8], 'BackgroundColor', [0.95 0.97 1], 'BorderType', 'etchedin', 'Position', [0.05, 0.2, 0.9, 0.17]);
    tankData.graphics.historyText = uicontrol('Parent', historyPanel, 'Style', 'edit', 'Max', 10, 'Min', 0, 'String', {'Inflow History:', 'Current: 0.000 m³/s', 'Maximum: 0.000 m³/s', 'Minimum: 0.000 m³/s', 'Rate: 0.000 m³/s²'}, 'HorizontalAlignment', 'left', 'FontName', 'FixedWidth', 'FontSize', 9, 'BackgroundColor', [0.98 0.98 1], 'Enable', 'inactive', 'Position', [10, 10, 350, 70]);
end

function initializeControlPanel()
    global tankData;
    panel = tankData.panels.data;
    controlPanel = uipanel('Parent', panel, 'Title', 'CONTROLS', 'FontSize', 12, 'FontWeight', 'bold', 'ForegroundColor', [0 0.4 0.8], 'BackgroundColor', [1 1 1], 'BorderType', 'etchedin', 'Position', [0.05, 0.02, 0.9, 0.15]);
    buttons = {
        {'INFLOW PLOT', @inflowPlotCallback, [0.05, 0.6, 0.4, 0.3]};
        {'EXPORT DATA', @exportDataCallback, [0.55, 0.6, 0.4, 0.3]};
        {'HELP', @helpCallback, [0.05, 0.2, 0.4, 0.3]};
        {'INFO', @infoCallback, [0.55, 0.2, 0.4, 0.3]};
    };
    for i = 1:length(buttons)
        btnText = buttons{i}{1};
        callback = buttons{i}{2};
        pos = buttons{i}{3};
        uicontrol('Parent', controlPanel, 'Style', 'pushbutton', 'String', btnText, 'FontSize', 9, 'FontWeight', 'bold', 'Callback', callback, 'Position', [pos(1)*360, pos(2)*70, pos(3)*360, pos(4)*70]);
    end
end

function updateRealTimeDisplay()
    global tankData;
    if ~tankData.isInitialized
        return;
    end
    t = tankData.current.time;
    currentHeight = tankData.current.level;
    inflow = tankData.current.inflow;
    outflow = tankData.current.outflow;
    setpoint = tankData.current.setpoint;
    inflowStr = sprintf('%.3f', inflow);
    set(tankData.graphics.inflowDisplay, 'String', inflowStr);
    set(tankData.graphics.inflowIndicator, 'String', sprintf('Inflow: %.3f m³/s | Height: %.3f m', inflow, currentHeight));
    set(tankData.graphics.statusText, 'String', sprintf('INFLOW ANIMATION: Inflow=%.3f m³/s | Height=%.3f m | Time=%.1f s', inflow, currentHeight, t));
    set(tankData.graphics.timeDisplay, 'String', sprintf('%.1f', t));
    set(tankData.graphics.inflowDisplay2, 'String', sprintf('%.4f', inflow));
    set(tankData.graphics.outflowDisplay, 'String', sprintf('%.4f', outflow));
    set(tankData.graphics.heightDisplay, 'String', sprintf('%.4f', currentHeight));
    set(tankData.graphics.setpointDisplay, 'String', sprintf('%.4f', setpoint));
    if tankData.history.index > 1
        prev_idx = mod(tankData.history.index-2, tankData.history.bufferSize) + 1;
        inflowRate = tankData.history.dinflow_dt(prev_idx);
    else
        inflowRate = 0;
    end
    set(tankData.graphics.inflowRateDisplay, 'String', sprintf('%.4f', inflowRate));
    updateTankVisualization();
    updateInflowHistoryDisplay();
    drawnow limitrate;
end

function updateTankVisualization()
    global tankData;
    if ~isfield(tankData.graphics, 'water') || ~isgraphics(tankData.graphics.water)
        return;
    end
    currentHeight = min(tankData.current.level, tankData.config.tankMaxHeight);
    inflow = tankData.current.inflow;
    outflow = tankData.current.outflow;
    displayWidth = tankData.graphics.displayWidth;
    waterX = [-displayWidth/2, displayWidth/2, displayWidth/2, -displayWidth/2];
    waterY = [0, 0, currentHeight, currentHeight];
    set(tankData.graphics.water, 'XData', waterX, 'YData', waterY);
    if inflow > 0.01
        set(tankData.graphics.inValve, 'FaceColor', [0 0.8 0]);
        set(tankData.graphics.inflowStatus, 'String', 'ACTIVE', 'ForegroundColor', [0 0.6 0]);
        set(tankData.graphics.inflowStatus, 'BackgroundColor', [0.9 1 0.9]);
    else
        set(tankData.graphics.inValve, 'FaceColor', [1 0.3 0.3]);
        set(tankData.graphics.inflowStatus, 'String', 'IDLE', 'ForegroundColor', [0.5 0.5 0.5]);
        set(tankData.graphics.inflowStatus, 'BackgroundColor', [1 1 1]);
    end
    if outflow > 0.01
        set(tankData.graphics.outValve, 'FaceColor', [0 0.8 0]);
    else
        set(tankData.graphics.outValve, 'FaceColor', [1 0.3 0.3]);
    end
    if isfield(tankData.graphics, 'inflowText') && isgraphics(tankData.graphics.inflowText)
        set(tankData.graphics.inflowText, 'Position', [displayWidth/2 + 0.8, currentHeight, 0], 'String', sprintf('%.3f m³/s', inflow));
        if inflow > 0.5
            set(tankData.graphics.inflowText, 'Color', [0 0.8 0], 'EdgeColor', [0 0.8 0]);
        elseif inflow > 0.1
            set(tankData.graphics.inflowText, 'Color', [0 0.6 0], 'EdgeColor', [0 0.6 0]);
        else
            set(tankData.graphics.inflowText, 'Color', [0.5 0.5 0.5], 'EdgeColor', [0.5 0.5 0.5]);
        end
    end
    fillPercent = (currentHeight / tankData.config.tankMaxHeight) * 100;
    inflowIntensity = min(abs(inflow) / tankData.config.maxInflow, 1.0);
    if inflow > 0
        waterColor = [0.2, 0.5 + inflowIntensity*0.4, 0.9 - inflowIntensity*0.4];
    else
        waterColor = [0.2, 0.5, 0.9];
    end
    set(tankData.graphics.water, 'FaceColor', waterColor);
end

function updateInflowHistoryDisplay()
    global tankData;
    if ~isfield(tankData.graphics, 'historyText')
        return;
    end
    currentInflow = tankData.current.inflow;
    maxInflow = tankData.statistics.maxInflow;
    minInflow = tankData.statistics.minInflow;
    currentHeight = tankData.current.level;
    if tankData.history.index > 1
        prev_idx = mod(tankData.history.index-2, tankData.history.bufferSize) + 1;
        inflowRate = tankData.history.dinflow_dt(prev_idx);
    else
        inflowRate = 0;
    end
    historyText = {
        sprintf('INFLOW HISTORY:');
        sprintf('Current Inflow: %.3f m³/s', currentInflow);
        sprintf('Current Height: %.3f m', currentHeight);
        sprintf('Maximum Inflow: %.3f m³/s (at t=%.1f s)', maxInflow, tankData.statistics.maxInflowTime);
        sprintf('Minimum Inflow: %.3f m³/s (at t=%.1f s)', minInflow, tankData.statistics.minInflowTime);
        sprintf('Inflow Rate: %.4f m³/s²', inflowRate);
    };
    set(tankData.graphics.historyText, 'String', historyText);
end

function updateFinalStateDisplay()
    global tankData;
    set(tankData.figure, 'Name', 'Inflow Animation (Simulation Complete)');
    set(tankData.graphics.statusText, 'String', sprintf('SIMULATION COMPLETE | Final Inflow: %.3f m³/s | Final Height: %.3f m', tankData.current.inflow, tankData.current.level));
    set(tankData.graphics.inflowIndicator, 'String', sprintf('FINAL: %.3f m³/s | Height: %.3f m', tankData.current.inflow, tankData.current.level));
    updateInflowHistoryDisplay();
end

function showInflowSummary()
    global tankData;
    summaryText = {
        '=== INFLOW ANIMATION SUMMARY ===';
        sprintf('Simulation Duration: %.1f seconds', tankData.current.time);
        sprintf('Final Inflow Rate: %.3f m³/s', tankData.current.inflow);
        sprintf('Final Tank Height: %.3f meters', tankData.current.level);
        sprintf('Maximum Inflow: %.3f m³/s (at t=%.1f s)', tankData.statistics.maxInflow, tankData.statistics.maxInflowTime);
        sprintf('Minimum Inflow: %.3f m³/s (at t=%.1f s)', tankData.statistics.minInflow, tankData.statistics.minInflowTime);
        sprintf('Maximum Height: %.3f meters (at t=%.1f s)', tankData.statistics.maxHeight, tankData.statistics.maxHeightTime);
        sprintf('Minimum Height: %.3f meters (at t=%.1f s)', tankData.statistics.minHeight, tankData.statistics.minHeightTime);
        sprintf('Inflow Range: %.3f m³/s', tankData.statistics.maxInflow - tankData.statistics.minInflow);
        sprintf('Data Points Collected: %d', tankData.history.index);
        '';
        'Animation shows inflow rate with color intensity';
        'Green = active inflow, Red = idle';
    };
    msgbox(summaryText, 'Inflow Summary - Simulation Complete', 'modal');
end

function closeTankGUI(~, ~)
    global tankData tankFig;
    choice = questdlg('Close Inflow Animation?', 'Confirm Close', 'Yes, Close', 'No, Keep Open', 'No, Keep Open');
    if strcmp(choice, 'Yes, Close')
        try
            if tankData.isInitialized
                inflowData = struct();
                inflowData.finalInflow = tankData.current.inflow;
                inflowData.finalHeight = tankData.current.level;
                inflowData.maxInflow = tankData.statistics.maxInflow;
                inflowData.minInflow = tankData.statistics.minInflow;
                inflowData.simulationTime = tankData.current.time;
                save('inflow_animation_results.mat', 'inflowData');
                fprintf('Inflow animation data saved to inflow_animation_results.mat\n');
            end
        catch ME
            fprintf('Warning: Could not save inflow data: %s\n', ME.message);
        end
        if isgraphics(tankFig)
            delete(tankFig);
        end
        clear global tankData tankFig;
        fprintf('Inflow Animation GUI closed\n');
    end
end

function resizeGUI(~, ~)
end

function inflowPlotCallback(~, ~)
    global tankData;
    if tankData.history.index < 2
        msgbox('Not enough data for plotting. Wait for more data points.', 'Insufficient Data');
        return;
    end
    n = min(tankData.history.index, tankData.history.bufferSize);
    idx = mod((1:n) + tankData.history.index - n - 1, tankData.history.bufferSize) + 1;
    timeData = tankData.history.time(idx);
    heightData = tankData.history.level(idx);
    inflowData = tankData.history.inflow(idx);
    outflowData = tankData.history.outflow(idx);
    setpointData = tankData.history.setpoint(idx);
    inflowFig = figure('Name', 'Inflow Analysis', 'NumberTitle', 'off', 'Position', [100, 100, 1200, 800]);
    subplot(3, 2, [1, 2]);
    plot(timeData, inflowData, 'g-', 'LineWidth', 3);
    hold on;
    plot(timeData(end), inflowData(end), 'ro', 'MarkerSize', 12, 'MarkerFaceColor', 'r');
    xlabel('Time (s)', 'FontSize', 12);
    ylabel('Inflow Rate (m³/s)', 'FontSize', 12, 'FontWeight', 'bold');
    title('Inflow Rate vs Time (Green Graph)', 'FontSize', 14, 'FontWeight', 'bold');
    grid on;
    legend({'Inflow', sprintf('Final: %.3f m³/s', inflowData(end))}, 'Location', 'best');
    subplot(3, 2, [3, 4]);
    plot(timeData, heightData, 'b-', 'LineWidth', 2);
    hold on;
    plot(timeData, setpointData, 'r--', 'LineWidth', 2);
    xlabel('Time (s)', 'FontSize', 12);
    ylabel('Height (m)', 'FontSize', 12);
    title('Tank Height vs Setpoint', 'FontSize', 14, 'FontWeight', 'bold');
    grid on;
    legend({'Height', 'Setpoint'}, 'Location', 'best');
    subplot(3, 2, 5);
    plot(timeData, outflowData, 'r-', 'LineWidth', 2);
    xlabel('Time (s)', 'FontSize', 12);
    ylabel('Outflow Rate (m³/s)', 'FontSize', 12);
    title('Outflow Rate', 'FontSize', 14, 'FontWeight', 'bold');
    grid on;
    subplot(3, 2, 6);
    scatter(inflowData, heightData, 20, 'filled');
    xlabel('Inflow Rate (m³/s)', 'FontSize', 12);
    ylabel('Tank Height (m)', 'FontSize', 12);
    title('Height vs Inflow Correlation', 'FontSize', 14);
    grid on;
    statsFig = figure('Name', 'Inflow Statistics', 'NumberTitle', 'off', 'Position', [300, 100, 800, 600]);
    inflowStats = struct();
    inflowStats.mean = mean(inflowData);
    inflowStats.std = std(inflowData);
    inflowStats.median = median(inflowData);
    inflowStats.max = max(inflowData);
    inflowStats.min = min(inflowData);
    inflowStats.totalVolume = trapz(timeData, inflowData);
    heightStats = struct();
    heightStats.mean = mean(heightData);
    heightStats.std = std(heightData);
    heightStats.max = max(heightData);
    heightStats.min = min(heightData);
    axis off;
    statsText = {
        sprintf('=== INFLOW STATISTICS ===');
        sprintf('Current: %.3f m³/s', inflowData(end));
        sprintf('Maximum: %.3f m³/s', inflowStats.max);
        sprintf('Minimum: %.3f m³/s', inflowStats.min);
        sprintf('Average: %.3f m³/s', inflowStats.mean);
        sprintf('Median: %.3f m³/s', inflowStats.median);
        sprintf('Std Dev: %.3f m³/s', inflowStats.std);
        sprintf('Total Inflow Volume: %.1f m³', inflowStats.totalVolume);
        '';
        sprintf('=== HEIGHT STATISTICS ===');
        sprintf('Current: %.3f m', heightData(end));
        sprintf('Maximum: %.3f m', heightStats.max);
        sprintf('Minimum: %.3f m', heightStats.min);
        sprintf('Average: %.3f m', heightStats.mean);
        sprintf('Std Dev: %.3f m', heightStats.std);
        '';
        sprintf('=== SYSTEM INFORMATION ===');
        sprintf('MAX TANK HEIGHT: %.1f m', tankData.config.tankMaxHeight);
        sprintf('MAX INFLOW RATE: %.1f m³/s', tankData.config.maxInflow);
        sprintf('Time at Max Inflow: %.1f s', tankData.statistics.maxInflowTime);
        sprintf('Time at Min Inflow: %.1f s', tankData.statistics.minInflowTime);
        '';
        sprintf('=== CORRELATION ===');
        sprintf('Height-Inflow Correlation: %.3f', corr(heightData(:), inflowData(:)));
        sprintf('Data Points: %d', n);
    };
    text(0.1, 0.5, statsText, 'FontSize', 11, 'FontName', 'FixedWidth', 'VerticalAlignment', 'middle');
    saveas(inflowFig, 'inflow_analysis.png');
    saveas(statsFig, 'inflow_statistics.png');
    fprintf('Inflow analysis plots saved\n');
end

function exportDataCallback(~, ~)
    global tankData;
    if tankData.history.index < 2
        msgbox('Not enough data to export.', 'Insufficient Data');
        return;
    end
    n = min(tankData.history.index, tankData.history.bufferSize);
    idx = mod((1:n) + tankData.history.index - n - 1, tankData.history.bufferSize) + 1;
    exportData = struct();
    exportData.time = tankData.history.time(idx);
    exportData.inflow = tankData.history.inflow(idx);
    exportData.height = tankData.history.level(idx);
    exportData.outflow = tankData.history.outflow(idx);
    exportData.setpoint = tankData.history.setpoint(idx);
    exportData.tankMaxHeight = tankData.config.tankMaxHeight;
    exportData.tankDiameter = tankData.config.tankDiameter;
    exportData.maxInflow = tankData.config.maxInflow;
    exportData.timestamp = datestr(now);
    exportData.statistics = tankData.statistics;
    assignin('base', 'inflowAnimationData', exportData);
    [filename, pathname] = uiputfile({'*.mat'; '*.csv'; '*.xlsx'}, 'Save Inflow Data As', 'inflow_animation_data.mat');
    if filename ~= 0
        fullpath = fullfile(pathname, filename);
        [~, ~, ext] = fileparts(filename);
        if strcmpi(ext, '.mat')
            save(fullpath, 'exportData');
            msg = 'MAT file saved';
        elseif strcmpi(ext, '.csv')
            csvData = [exportData.time(:), exportData.inflow(:), exportData.height(:), exportData.outflow(:), exportData.setpoint(:)];
            csvHeader = {'Time_s', 'Inflow_m3_s', 'Height_m', 'Outflow_m3_s', 'Setpoint_m'};
            fid = fopen(fullpath, 'w');
            fprintf(fid, '%s,%s,%s,%s,%s\n', csvHeader{:});
            for i = 1:size(csvData, 1)
                fprintf(fid, '%.6f,%.6f,%.6f,%.6f,%.6f\n', csvData(i, :));
            end
            fclose(fid);
            msg = 'CSV file saved';
        elseif strcmpi(ext, '.xlsx')
            msg = 'Excel export requires additional setup. Data saved to workspace only.';
        end
        msgbox(sprintf('%s\n\nInflow data also available in workspace as "inflowAnimationData"', msg), 'Export Complete', 'modal');
    else
        msgbox('Inflow data saved to workspace variable "inflowAnimationData"', 'Export Complete', 'modal');
    end
end

function helpCallback(~, ~)
    helpText = {
        '=== INFLOW ANIMATION HELP ===';
        '';
        'PURPOSE:';
        'Display inflow rate animation and tank height';
        '';
        'VISUALIZATION:';
        '• Left: Tank with color intensity showing inflow rate';
        '• Water color changes with inflow intensity';
        '• Green valve = active inflow, Red = idle';
        '• Green text shows current inflow rate';
        '';
        'DATA DISPLAYS:';
        '• Large inflow display (green)';
        '• Inflow status indicator';
        '• System data including height and outflow';
        '• Inflow history with min/max values';
        '';
        'ANIMATION FEATURES:';
        '• Water color intensity = inflow rate';
        '• Valve color indicates flow status';
        '• Real-time inflow rate display';
        '';
        'CONTROLS:';
        '• INFLOW PLOT: Generate inflow analysis graphs';
        '• EXPORT DATA: Save inflow data to file';
        '• HELP: This information';
        '• INFO: System information';
    };
    msgbox(helpText, 'Help - Inflow Animation', 'modal');
end

function infoCallback(~, ~)
    global tankData;
    tankRadius = tankData.config.tankDiameter / 2;
    tankArea = pi * tankRadius^2;
    maxVolume = tankData.config.tankMaxHeight * tankArea;
    infoText = {
        '=== INFLOW ANIMATION SYSTEM ===';
        sprintf('Tank Maximum Height: %.1f meters', tankData.config.tankMaxHeight);
        sprintf('Tank Diameter: %.1f meters', tankData.config.tankDiameter);
        sprintf('Maximum Inflow Rate: %.1f m³/s', tankData.config.maxInflow);
        sprintf('Tank Cross-sectional Area: %.2f m²', tankArea);
        sprintf('Maximum Tank Volume: %.1f m³', maxVolume);
        '';
        'ANIMATION:';
        '• Water color intensity represents inflow rate';
        '• Bright green = high inflow, Blue = low/no inflow';
        '• Valve color shows flow status';
        '';
        'DATA COLLECTION:';
        sprintf('Buffer Size: %d points', tankData.history.bufferSize);
        sprintf('Current Data Points: %d', tankData.history.index);
        '';
        'The green graph shows inflow rate over time.';
    };
    msgbox(infoText, 'System Information', 'modal');
end

function generateFinalPlots()
    global tankData;
    if tankData.history.index < 2
        return;
    end
    n = min(tankData.history.index, tankData.history.bufferSize);
    idx = mod((1:n) + tankData.history.index - n - 1, tankData.history.bufferSize) + 1;
    timeData = tankData.history.time(idx);
    heightData = tankData.history.level(idx);
    inflowData = tankData.history.inflow(idx);
    setpointData = tankData.history.setpoint(idx);
    finalFig = figure('Name', 'Final Inflow Analysis - Simulation Complete', 'NumberTitle', 'off', 'Position', [150, 100, 1400, 900]);
    subplot(3, 3, [1, 2, 4, 5]);
    plot(timeData, inflowData, 'g-', 'LineWidth', 3);
    hold on;
    yline(tankData.config.maxInflow, 'r--', 'LineWidth', 2.5);
    plot(tankData.statistics.maxInflowTime, tankData.statistics.maxInflow, 'go', 'MarkerSize', 15, 'MarkerFaceColor', 'g');
    plot(tankData.statistics.minInflowTime, tankData.statistics.minInflow, 'mo', 'MarkerSize', 15, 'MarkerFaceColor', 'm');
    plot(timeData(end), inflowData(end), 'ro', 'MarkerSize', 15, 'MarkerFaceColor', 'r');
    xlabel('Time (seconds)', 'FontSize', 12);
    ylabel('Inflow Rate (m³/s)', 'FontSize', 12, 'FontWeight', 'bold');
    title('Complete Inflow History - Green Graph', 'FontSize', 16, 'FontWeight', 'bold');
    grid on;
    legendStr = {
        'Inflow';
        sprintf('Max Inflow: %.1f m³/s', tankData.config.maxInflow);
        sprintf('Max: %.3f m³/s', tankData.statistics.maxInflow);
        sprintf('Min: %.3f m³/s', tankData.statistics.minInflow);
        sprintf('Final: %.3f m³/s', inflowData(end))
    };
    legend(legendStr, 'Location', 'best', 'FontSize', 10);
    subplot(3, 3, [3, 6]);
    plot(timeData, heightData, 'b-', 'LineWidth', 2);
    hold on;
    plot(timeData, setpointData, 'r--', 'LineWidth', 2);
    xlabel('Time (s)');
    ylabel('Height (m)');
    title('Height vs Setpoint');
    grid on;
    legend('Height', 'Setpoint', 'Location', 'best');
    subplot(3, 3, 7);
    histogram(inflowData, 20, 'FaceColor', [0.2 0.8 0.4], 'EdgeColor', 'k');
    xlabel('Inflow (m³/s)');
    ylabel('Frequency');
    title('Inflow Distribution');
    grid on;
    hold on;
    xline(mean(inflowData), 'r-', 'LineWidth', 2);
    xline(median(inflowData), 'g-', 'LineWidth', 2);
    legend('Distribution', sprintf('Mean: %.3f', mean(inflowData)), sprintf('Median: %.3f', median(inflowData)));
    subplot(3, 3, 8);
    scatter(inflowData, heightData, 20, 'filled');
    xlabel('Inflow (m³/s)');
    ylabel('Height (m)');
    title('Height vs Inflow Correlation');
    grid on;
    subplot(3, 3, 9);
    plot(timeData, setpointData - heightData, 'm-', 'LineWidth', 2);
    xlabel('Time (s)');
    ylabel('Error (m)');
    title('Control Error (Setpoint - Height)');
    grid on;
    yline(0, 'k--');
    saveas(finalFig, 'inflow_final_analysis.png');
    fprintf('Final inflow analysis saved as inflow_final_analysis.png\n');
end
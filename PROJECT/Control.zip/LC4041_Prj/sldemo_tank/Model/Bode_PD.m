clc; clear; close all;

% -------------------------
% Plant
% -------------------------
G = tf(0.01,[1 0.03]);

% -------------------------
% PD Controller
% -------------------------
Kp = 162;
Kd = 59;

C = tf([Kd Kp],1);   % Kd*s + Kp

% -------------------------
% Open-loop
% -------------------------
L = C*G;

% -------------------------
% Bode Plot
% -------------------------
figure;
bode(L);
grid on;
title('Bode Diagram of L(s) = C(s)G(s) with PD');

% -------------------------
% Gain & Phase Margins
% -------------------------
figure;
margin(L);
grid on;

[GM, PM, Wcg, Wcp] = margin(L);

fprintf('\n----- Stability Margins -----\n');
fprintf('Gain Margin (dB)  = %.2f dB\n', 20*log10(GM));
fprintf('Phase Margin      = %.2f deg\n', PM);
fprintf('Gain Crossover w  = %.4f rad/s\n', Wcg);
fprintf('Phase Crossover w = %.4f rad/s\n', Wcp);
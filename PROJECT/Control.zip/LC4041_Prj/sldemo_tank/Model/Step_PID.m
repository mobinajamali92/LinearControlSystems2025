clc; clear; close all;

alpha = 3.3;
G = tf(1,[100 alpha]);
s = tf('s');

Kp = 345;
Ki = 138;
Kd = 50;
N  = 1;

% PID with derivative filter: Kp + Ki/s + Kd*(N*s)/(1 + N*s)
C = Kp + Ki/s + Kd*(N*s)/(1 + N*s);

L = C*G;
figure; margin(L); grid on; title('Open-loop Bode + Margins (PID*G)');

T = feedback(L,1);
figure; step(10*T, 20); grid on; title('Closed-loop step (0->10) with PID');

info = stepinfo(10*T);
disp(info);
fprintf('Final value = %.4f\n', dcgain(10*T));
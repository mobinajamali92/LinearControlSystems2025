clc; clear;

alpha = 1;
A = 100;
G = tf(1, [A alpha]);

t = 0:0.1:500;
r = t;
[y, t_out] = lsim(G, r, t);


figure;
plot(t_out, y, 'LineWidth', 2);
grid on;
title('Ramp Response of the System');
xlable('Time (s)');
ylable('h(t)');
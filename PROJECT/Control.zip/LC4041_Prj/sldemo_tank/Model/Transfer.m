clc; clear; close all;

A = 100;
alpha = 3.3;

num = 1/A;
den = [1  alpha/A];

G = tf(num, den)
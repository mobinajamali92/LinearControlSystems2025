clc; clear; close all;
s = tf('s');

%% Plant
G = 1/(100*s + 3.3);

%% PID (Simulink PID block: Parallel + filtered derivative)
Kp = 345;
Ki = 138;
Kd = 50;
N  = 1;

C = Kp + Ki/s + Kd*(N*s)/(s+N);

%% Open-loop
L = C*G;

figure;
margin(L); grid on;
title('Bode + Margins for L(s)=C(s)G(s) (Your PID gains)');

[GM, PM, Wcg, Wcp] = margin(L);
fprintf('Phase Margin PM = %.2f deg\n', PM);
fprintf('Gain Crossover Wcp = %.3f rad/s\n', Wcp);
fprintf('Gain Margin GM = %.2f dB\n', 20*log10(GM));


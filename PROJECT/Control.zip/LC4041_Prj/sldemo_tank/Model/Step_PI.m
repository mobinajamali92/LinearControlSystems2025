clc; clear; close all;

% Plant
G = tf(0.01,[1 0.03]);


% PI Controller
Kp = 375;
Ki = 560;
C = tf([Kp Ki],[1 0]);   % (Kp*s + Ki)/s


T = feedback(C*G,1);

figure;
step(10*T , 20 );
grid on;
title('Closed-Loop Step Response with PI');

info = stepinfo(T);

fprintf('\n----- Step Response Specs -----\n');
fprintf('Rise Time      = %.4f s\n', info.RiseTime);
fprintf('Settling Time  = %.4f s\n', info.SettlingTime);
fprintf('Overshoot      = %.2f %%\n', info.Overshoot);
fprintf('Peak Time      = %.4f s\n', info.PeakTime);
fprintf('Peak Value     = %.4f\n', info.Peak);
clc; clear; close all;
s = tf('s');

%% Plant
G = 0.01/(s + 0.03);   


Kp = 375;
Ki = 560;
C = Kp + Ki/s;

%% Open-loop without filter
L0 = C*G;

%% Measurement low-pass filter candidates
tau_list = [0.01 0.05 0.1 0.2];  %%trade-off

figure;
margin(L0); grid on;
title('Open-loop without measurement filter');

[GM0, PM0, ~, Wcp0] = margin(L0);
fprintf('--- Without filter ---\nPM = %.2f deg, Wcp = %.3f rad/s\n\n', PM0, Wcp0);

for tau = tau_list
    F = 1/(tau*s + 1);      % low-pass on measurement
    Lf = C*G*F;             % open-loop with filter
    
    [GM, PM, ~, Wcp] = margin(Lf);
    fprintf('tau = %.3f  --> PM = %.2f deg, Wcp = %.3f rad/s\n', tau, PM, Wcp);
end

%% Compare bode
figure;
bodemag(L0); grid on; hold on;
for tau = tau_list
    F = 1/(tau*s + 1);
    bodemag(C*G*F);
end
title('Bode Magnitude: effect of measurement low-pass filter');
legend('No filter','tau=0.01','tau=0.05','tau=0.1','tau=0.2');
clc; clear; close all;

G = tf(0.01,[1 0.03]);

Kp = 162;
Kd = 59;

C = tf([Kd Kp],1);   % Kd*s + Kp

L = C*G;

figure;
margin(L);
grid on;

T = feedback(L,1);

figure;
step(10*T, 20);
grid on;

info = stepinfo(T);

fprintf('Overshoot = %.2f %%\n', info.Overshoot);
fprintf('Settling Time = %.3f s\n', info.SettlingTime);

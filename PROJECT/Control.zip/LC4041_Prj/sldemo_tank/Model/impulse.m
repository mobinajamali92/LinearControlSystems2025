alpha = 1;
A = 100;
G = tf(1, [A alpha]);

figure;
impulse(G);
grid on;
title('Impulse Response of the System');
xlable('Time (s)');
ylable('h(t)');
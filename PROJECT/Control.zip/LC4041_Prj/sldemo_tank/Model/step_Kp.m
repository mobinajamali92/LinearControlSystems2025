clc; clear; close all;
% Plant
G = tf(0.01, [1 0.03]);  

Kp = 100;                   
T = feedback(Kp*G, 1);   

figure;
step(10*T, 20); grid on;
title(['Closed-loop Step with P, Kp=', num2str(Kp)]);

info = stepinfo(T);
disp(info)
fprintf('Overshoot = %.2f %%\n', info.Overshoot);
fprintf('SettlingTime(2%%) = %.3f s\n', info.SettlingTime);
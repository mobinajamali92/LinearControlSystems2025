clc; clear; close all;

G = tf(0.01, [1 0.03]);

figure;
margin(G);      % رسم بودی + GM و PM
grid on;

[GM, PM, Wcg, Wcp] = margin(G);

fprintf('Gain Margin = %.2f dB\n', 20*log10(GM));
fprintf('Phase Margin = %.2f deg\n', PM);
fprintf('Gain crossover freq = %.4f rad/s\n', Wcg);
fprintf('Phase crossover freq = %.4f rad/s\n', Wcp);